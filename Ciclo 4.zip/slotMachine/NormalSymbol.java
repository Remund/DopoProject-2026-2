/**
 * NormalSymbol es el símbolo de siempre (ciclos 1 a 3): se dibuja como
 * un círculo de tamaño fijo y no cambia al ser seleccionado.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class NormalSymbol extends Symbol{

    /**
     * Crea un símbolo normal del color indicado.
     * @param color nombre del color CSS del símbolo
     */
    public NormalSymbol(String color){
        super(color);
    }

    /**
     * Un símbolo normal se dibuja como un círculo.
     * @return "circle"
     */
    @Override
    public String shape(){
        return "circle";
    }
}
