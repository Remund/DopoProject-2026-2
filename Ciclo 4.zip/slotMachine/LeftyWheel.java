import java.util.ArrayList;

/**
 * LeftyWheel es una rueda zurda: si hay una rueda a su izquierda, al
 * girar copia su estado (queda mostrando el mismo símbolo que ella). Si
 * es la primera rueda de la máquina, gira como una rueda normal. Su
 * marco es azul claro.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class LeftyWheel extends Wheel{

    private Wheel left;

    /**
     * Crea una rueda zurda (aún sin vecina a la izquierda).
     * @param catalog   catálogo de símbolos de la máquina
     * @param xPosition posición horizontal inicial de la rueda
     */
    public LeftyWheel(ArrayList<Symbol> catalog, int xPosition){
        super(catalog, xPosition);
        left = null;
    }

    /**
     * Recuerda cuál es la rueda que tiene a su izquierda.
     * @param left rueda de la izquierda, o null si es la primera
     */
    @Override
    public void setLeftNeighbor(Wheel left){
        this.left = left;
    }

    /**
     * Al girar al azar copia el símbolo de la rueda de la izquierda.
     */
    @Override
    protected void turn(){
        if(!copyLeft()){ super.turn(); }
    }

    /**
     * Al rotar también copia el símbolo de la rueda de la izquierda.
     * @param steps pasos (sólo se usan si no hay rueda a la izquierda)
     */
    @Override
    protected void rotate(int steps){
        if(!copyLeft()){ super.rotate(steps); }
    }

    /**
     * El marco de una rueda zurda es azul claro.
     * @return "lightskyblue"
     */
    @Override
    protected String frameColor(){
        return "lightskyblue";
    }

    /**
     * Copia el símbolo que muestra la rueda de la izquierda.
     * @return true si había una rueda a la izquierda con símbolo
     */
    private boolean copyLeft(){
        return left != null && left.currentSymbol() != null
            && showColor(left.currentSymbol());
    }
}
