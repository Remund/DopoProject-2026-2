import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad del TERCER CICLO, requisito 13: la máquina de n
 * ruedas y n símbolos, SlotMachine(n). Todas en modo INVISIBLE.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class SlotMachineC3Test{

    private SlotMachine machine;

    /**
     * Crea el conjunto de pruebas.
     */
    public SlotMachineC3Test(){
        super();
    }

    /**
     * Antes de cada prueba no se necesita una máquina compartida: cada
     * caso crea la suya con SlotMachine(n).
     */
    @BeforeEach
    public void setUp(){
        machine = null;
    }

    /**
     * Limpia después de cada prueba: suelta la máquina usada.
     */
    @AfterEach
    public void tearDown(){
        machine = null;
    }

    // ---------- Requisito 13: SlotMachine(n) ----------

    /**
     * SlotMachine(n) debería crear n ruedas y n símbolos.
     */
    @Test
    public void shouldCreateNWheelsAndNSymbols(){
        machine = new SlotMachine(5);
        assertEquals(5, machine.wheelCount());
        assertEquals(5, machine.symbols().length);
        assertTrue(machine.ok());
    }

    /**
     * SlotMachine(n) NO debería repetir colores en sus símbolos.
     */
    @Test
    public void shouldNotRepeatSymbolColors(){
        machine = new SlotMachine(20);
        String[] symbols = machine.symbols();
        for(int i = 0; i < symbols.length; i++){
            for(int j = i + 1; j < symbols.length; j++){
                assertNotEquals(symbols[i], symbols[j]);
            }
        }
    }

    /**
     * SlotMachine(n) NO debería empezar en jackpot ni visible.
     */
    @Test
    public void shouldNotStartInJackpotNorVisible(){
        for(int i = 0; i < 50; i++){
            machine = new SlotMachine(3);
            assertFalse(machine.isJackpot());
            assertFalse(machine.isVisible());
        }
    }

    /**
     * SlotMachine(n) debería dejar toda rueda mostrando un símbolo de su
     * catálogo.
     */
    @Test
    public void shouldShowASymbolOfTheCatalogOnEveryWheel(){
        machine = new SlotMachine(6);
        java.util.List<String> catalog = java.util.Arrays.asList(machine.symbols());
        for(String shown : machine.configuration()){
            assertTrue(catalog.contains(shown));
        }
    }
}
