import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad de la solución de la maratón (requisito 14):
 * SlotMachineContest.solve. Todas en modo INVISIBLE. simulate
 * (requisito 15) se verifica en las pruebas de aceptación, porque
 * necesita el simulador visible.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class SlotMachineContestTest{

    private SlotMachine machine;

    /**
     * Crea el conjunto de pruebas.
     */
    public SlotMachineContestTest(){
        super();
    }

    /**
     * Antes de cada prueba no se necesita una máquina compartida: cada
     * caso crea la suya con SlotMachine(n).
     */
    @BeforeEach
    public void setUp(){
        machine = null;
    }

    /**
     * Limpia después de cada prueba: suelta la máquina usada.
     */
    @AfterEach
    public void tearDown(){
        machine = null;
    }

    // ---------- Requisito 14: solve ----------

    /**
     * solve debería dejar la máquina en jackpot (k = 1) para varios n.
     */
    @Test
    public void shouldSolveMachinesOfSeveralSizes(){
        for(int n = 2; n <= 50; n++){
            machine = new SlotMachine(n);
            SlotMachineContest.solve(machine, n);
            assertEquals(1, machine.distinctSymbols());
            assertTrue(machine.isJackpot());
        }
    }

    /**
     * solve debería retornar acciones que llevan de la configuración
     * inicial a una ganadora.
     */
    @Test
    public void shouldReturnTheActionsFromTheInitialConfiguration(){
        machine = new SlotMachine(8);
        String[] initial = machine.configuration();
        int[][] actions = SlotMachineContest.solve(machine, 8);
        for(int[] a : actions) machine.spin(a[0], -a[1]);
        assertArrayEquals(initial, machine.configuration());
        for(int[] a : actions) machine.spin(a[0], a[1]);
        assertTrue(machine.isJackpot());
    }

    /**
     * solve NO debería retornar acciones sobre ruedas inexistentes ni
     * más de una acción por rueda.
     */
    @Test
    public void shouldNotReturnInvalidActions(){
        int n = 10;
        int[][] actions = SlotMachineContest.solve(n);
        assertTrue(actions.length <= n);
        for(int[] a : actions){
            assertEquals(2, a.length);
            assertTrue(a[0] >= 1 && a[0] <= n);
            assertTrue(a[1] != 0 && Math.abs(a[1]) <= n / 2);
        }
    }

    /**
     * solve NO debería mover nada si la máquina ya está en jackpot.
     */
    @Test
    public void shouldNotMoveAMachineAlreadyInJackpot(){
        machine = new SlotMachine(4);
        String c = machine.configuration()[0];
        machine.spin(new String[]{c, c, c, c});
        int[][] actions = SlotMachineContest.solve(machine, 4);
        assertEquals(0, actions.length);
        assertTrue(machine.isJackpot());
    }

    /**
     * solve NO debería hacer visible la máquina.
     */
    @Test
    public void shouldNotMakeTheMachineVisibleWhenSolving(){
        machine = new SlotMachine(5);
        SlotMachineContest.solve(machine, 5);
        assertFalse(machine.isVisible());
    }
    // ---------- Requisito 15: simulate ----------

    /**
     * simulate debería ejecutar la simulación visible de principio a fin.
     */
    @Test
    public void shouldSimulateTheSolutionUntilTheEnd(){
        boolean finished = false;
        SlotMachineContest.simulate(3);
        finished = true;
        assertTrue(finished);
    }

    /**
     * simulate NO debería fallar con una máquina de una sola rueda (que
     * ya está en jackpot y no necesita acciones).
     */
    @Test
    public void shouldNotFailSimulatingAMachineOfOneWheel(){
        boolean finished = false;
        SlotMachineContest.simulate(1);
        finished = true;
        assertTrue(finished);
        assertEquals(0, SlotMachineContest.solve(1).length);
    }
}
