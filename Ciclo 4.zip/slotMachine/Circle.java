import java.awt.*;
import java.awt.geom.*;

/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * Extendida con moveTo(x,y) y getters para el proyecto slotMachine.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 4.0
 */
public class Circle{

    public static final double PI=3.1416;

    private int diameter;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Crea un círculo en la posición y con el color por defecto.
     */
    public Circle(){
        diameter = 30;
        xPosition = 20;
        yPosition = 15;
        color = "blue";
        isVisible = false;
    }

    /**
     * Hace visible la figura.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible la figura.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }

    /**
     * Dibuja la figura en el lienzo si está visible.
     */
    private void draw(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new Ellipse2D.Double(xPosition, yPosition,
                diameter, diameter));
            canvas.wait(10);
        }
    }

    /**
     * Borra la figura del lienzo.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }

    /**
     * Mueve la figura 20 pixeles a la derecha.
     */
    public void moveRight(){ moveHorizontal(20); }
    /**
     * Mueve la figura 20 pixeles a la izquierda.
     */
    public void moveLeft(){ moveHorizontal(-20); }
    /**
     * Mueve la figura 20 pixeles hacia arriba.
     */
    public void moveUp(){ moveVertical(-20); }
    /**
     * Mueve la figura 20 pixeles hacia abajo.
     */
    public void moveDown(){ moveVertical(20); }

    /**
     * Mueve la figura horizontalmente.
     * @param distance pixeles a mover (negativo hacia la izquierda)
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve la figura verticalmente.
     * @param distance pixeles a mover (negativo hacia arriba)
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Mueve el círculo a una posición absoluta.
     * Extensión del paquete shapes para posicionar figuras directamente.
     * @param x nueva coordenada horizontal
     * @param y nueva coordenada vertical
     */
    public void moveTo(int x, int y){
        erase();
        xPosition = x;
        yPosition = y;
        draw();
    }

    /**
     * Mueve la figura horizontalmente, pixel por pixel.
     * @param distance pixeles a mover
     */
    public void slowMoveHorizontal(int distance){
        int delta;
        if(distance < 0) { delta = -1; distance = -distance; }
        else { delta = 1; }
        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Mueve la figura verticalmente, pixel por pixel.
     * @param distance pixeles a mover
     */
    public void slowMoveVertical(int distance){
        int delta;
        if(distance < 0) { delta = -1; distance = -distance; }
        else { delta = 1; }
        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Cambia el tamaño del círculo.
     * @param newDiameter nuevo diámetro en pixeles
     */
    public void changeSize(int newDiameter){
        erase();
        diameter = newDiameter;
        draw();
    }

    /**
     * Cambia el color de la figura.
     * @param newColor nombre del nuevo color
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }

    /**
     * Consulta el diámetro.
     * @return diámetro en pixeles
     */
    public int getDiameter(){ return diameter; }
    /**
     * Consulta la posición horizontal.
     * @return posición x
     */
    public int getXPosition(){ return xPosition; }
    /**
     * Consulta la posición vertical.
     * @return posición y
     */
    public int getYPosition(){ return yPosition; }
    /**
     * Consulta el color.
     * @return nombre del color
     */
    public String getColor(){ return color; }
    /**
     * Consulta si la figura está visible.
     * @return true si está visible
     */
    public boolean isVisible(){ return isVisible; }
}