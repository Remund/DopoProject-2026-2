import javax.swing.JOptionPane;

/**
 * Pruebas de aceptación del CUARTO CICLO (requisitos 16 a 19). Cada
 * prueba arma una máquina VISIBLE y va llamando sus métodos con pausas,
 * para que se vea en pantalla el efecto de cada operación.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class SlotMachineC4AcceptanceTest{

    private static final int PAUSE = 1200;

    /**
     * Ejecuta las dos pruebas de aceptación del ciclo 4.
     * @param args no se usan
     */
    public static void main(String[] args){
        wheelTypes();
        symbolTypes();
        System.exit(0);
    }

    /**
     * Aceptación 1 (requisitos 16, 17 y 19): tipos de ruedas.
     */
    public static void wheelTypes(){
        Canvas.getCanvas().clear();
        SlotMachine machine = new SlotMachine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("gambler", 4);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.spin(new String[]{"blue", "red", "green", "red"});
        machine.makeVisible();
        pause();
        announce("Ruedas: normal (gris), lefty (azul), rebel (naranja), gambler (morado).");
        machine.spin(2);
        pause();
        announce("spin(2): la lefty copió el símbolo de su vecina izquierda (blue).");
        machine.lock(3);
        pause();
        announce("lock(3): la rebel no se dejó fijar (se mostró el error).");
        machine.spin(new String[]{"green", "green", "green", "red"});
        pause();
        announce("Las tres primeras muestran green: la gambler es la última que falta.");
        machine.spin(4);
        pause();
        if(machine.isJackpot()){
            announce("spin(4): la gambler apostó y ganó. Jackpot (marcos dorados).");
        } else {
            announce("spin(4): la gambler apostó, pero esta vez perdió.");
        }
    }

    /**
     * Aceptación 2 (requisitos 16 y 18): tipos de símbolos.
     */
    public static void symbolTypes(){
        Canvas.getCanvas().clear();
        SlotMachine machine = new SlotMachine();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("ephemeral", 2, "blue");
        machine.addSymbol("shy", 3, "green");
        machine.makeVisible();
        pause();
        announce("Símbolos: red normal (círculo), blue ephemeral (cuadrado)\n"
            + "y green shy (triángulo).");
        for(int i = 0; i < 5; i++){
            machine.placeSymbol(1, "blue");
            pause();
        }
        announce("La rueda 1 seleccionó el ephemeral 5 veces: se encogió hasta casi un punto.");
        machine.placeSymbol(2, "green");
        pause();
        announce("La rueda 2 seleccionó el shy: ahora está invisible.");
        machine.placeSymbol(2, "green");
        pause();
        announce("Lo seleccionó otra vez: el shy vuelve a verse.");
    }

    /**
     * Le explica al usuario lo que acaba de pasar.
     * @param message mensaje para el usuario
     */
    private static void announce(String message){
        JOptionPane.showMessageDialog(null, message, "Prueba de aceptación - Ciclo 4",
            JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Pausa para que el efecto de la operación se alcance a ver.
     */
    private static void pause(){
        Canvas.getCanvas().wait(PAUSE);
    }
}
