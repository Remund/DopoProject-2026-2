import java.awt.*;

/**
 * A rectangle that can be manipulated and that draws itself on a canvas.
 * Extendida con moveTo(x,y) y getters para el proyecto slotMachine.
 *
 * @author  Michael Kolling and David J. Barnes (Modified)
 * @version 4.0
 */
public class Rectangle{

    public static int EDGES = 4;

    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Crea un rectángulo en la posición y con el color por defecto.
     */
    public Rectangle(){
        height = 30;
        width = 40;
        xPosition = 70;
        yPosition = 15;
        color = "magenta";
        isVisible = false;
    }

    /**
     * Hace visible la figura.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible la figura.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }

    /**
     * Mueve la figura 20 pixeles a la derecha.
     */
    public void moveRight(){ moveHorizontal(20); }
    /**
     * Mueve la figura 20 pixeles a la izquierda.
     */
    public void moveLeft(){ moveHorizontal(-20); }
    /**
     * Mueve la figura 20 pixeles hacia arriba.
     */
    public void moveUp(){ moveVertical(-20); }
    /**
     * Mueve la figura 20 pixeles hacia abajo.
     */
    public void moveDown(){ moveVertical(20); }

    /**
     * Mueve la figura horizontalmente.
     * @param distance pixeles a mover (negativo hacia la izquierda)
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve la figura verticalmente.
     * @param distance pixeles a mover (negativo hacia arriba)
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Mueve el rectángulo a una posición absoluta.
     * Extensión del paquete shapes.
     * @param x nueva posición horizontal
     * @param y nueva posición vertical
     */
    public void moveTo(int x, int y){
        erase();
        xPosition = x;
        yPosition = y;
        draw();
    }

    /**
     * Mueve la figura horizontalmente, pixel por pixel.
     * @param distance pixeles a mover
     */
    public void slowMoveHorizontal(int distance){
        int delta;
        if(distance < 0) { delta = -1; distance = -distance; }
        else { delta = 1; }
        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Mueve la figura verticalmente, pixel por pixel.
     * @param distance pixeles a mover
     */
    public void slowMoveVertical(int distance){
        int delta;
        if(distance < 0) { delta = -1; distance = -distance; }
        else { delta = 1; }
        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Cambia el tamaño del rectángulo.
     * @param newHeight nuevo alto en pixeles
     * @param newWidth nuevo ancho en pixeles
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }

    /**
     * Cambia el color de la figura.
     * @param newColor nombre del nuevo color
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }

    /**
     * Dibuja la figura en el lienzo si está visible.
     */
    private void draw() {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition,
                                       width, height));
            canvas.wait(10);
        }
    }

    /**
     * Borra la figura del lienzo.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }

    /**
     * Consulta el alto.
     * @return alto en pixeles
     */
    public int getHeight(){ return height; }
    /**
     * Consulta el ancho.
     * @return ancho en pixeles
     */
    public int getWidth(){ return width; }
    /**
     * Consulta la posición horizontal.
     * @return posición x
     */
    public int getXPosition(){ return xPosition; }
    /**
     * Consulta la posición vertical.
     * @return posición y
     */
    public int getYPosition(){ return yPosition; }
    /**
     * Consulta el color.
     * @return nombre del color
     */
    public String getColor(){ return color; }
    /**
     * Consulta si la figura está visible.
     * @return true si está visible
     */
    public boolean isVisible(){ return isVisible; }
}