import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda apostadora (tipo propuesto, requisito 19).
 * Si es la última rueda que falta para ganar (las demás tienen el mismo
 * símbolo), al girar apuesta: hace hasta 3 intentos y en cada intento es
 * más probable que salga el símbolo ganador (1 de 4, 2 de 4 y 3 de 4).
 * Si no es la última que falta, gira normal.
 * Su marco es morado.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class GamblerWheel extends Wheel{

    /** Número de intentos de una apuesta. */
    public static final int ATTEMPTS = 3;

    private String winningSymbol;
    private Random luck;

    /**
     * Crea una rueda apostadora.
     * @param catalog   catálogo de símbolos de la máquina
     * @param xPosition posición horizontal de la rueda
     */
    public GamblerWheel(ArrayList<Symbol> catalog, int xPosition){
        super(catalog, xPosition);
        winningSymbol = null;
        luck = new Random();
    }

    /**
     * Guarda el símbolo que le falta a la máquina para ganar.
     * @param symbol símbolo ganador, o null si esta rueda no es la última
     *               que falta
     */
    @Override
    public void setWinningSymbol(String symbol){
        winningSymbol = symbol;
    }

    /**
     * Gira la rueda. Si es la última que falta para ganar, apuesta hasta
     * 3 veces; si no, gira al azar.
     */
    @Override
    protected void turn(){
        if(winningSymbol == null){
            super.turn();
            return;
        }
        int attempt = 1;
        while(attempt <= ATTEMPTS && !isWinning()){
            if(luck.nextInt(4) < attempt){
                showColor(winningSymbol);
            } else {
                super.turn();
            }
            pauseStep();
            attempt++;
        }
        winningSymbol = null;
    }

    /**
     * El marco de la rueda apostadora es morado.
     * @return "plum"
     */
    @Override
    protected String frameColor(){
        return "plum";
    }

    /**
     * Revisa si la rueda ya muestra el símbolo ganador.
     * @return true si ya ganó
     */
    private boolean isWinning(){
        return winningSymbol.equals(currentSymbol());
    }
}
