/**
 * Símbolo de la máquina tragamonedas (clase abstracta).
 * Cada símbolo se identifica por su color CSS y no puede haber dos
 * símbolos del mismo color en la máquina.
 * Desde el ciclo 4 hay varios tipos de símbolos (NormalSymbol,
 * EphemeralSymbol y ShySymbol). Cada tipo decide con qué figura se dibuja,
 * de qué tamaño, si se ve o no, y qué pasa cuando una rueda lo selecciona.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public abstract class Symbol{

    /** Tamaño (en pixeles) con que se dibuja normalmente un símbolo. */
    public static final int SIZE = 50;

    private String color;

    /**
     * Crea un símbolo del color indicado.
     * @param color nombre del color CSS del símbolo
     */
    public Symbol(String color){
        this.color = normalize(color);
    }

    /**
     * Consulta el color del símbolo.
     * @return nombre del color CSS del símbolo
     */
    public String getColor(){
        return color;
    }

    /**
     * Indica si el símbolo tiene el color dado (sin importar mayúsculas
     * ni espacios alrededor).
     * @param otherColor color a comparar
     * @return true si el símbolo es de ese color
     */
    public boolean hasColor(String otherColor){
        return color.equals(normalize(otherColor));
    }

    /**
     * Consulta el tamaño con que se debe dibujar el símbolo.
     * @return tamaño en pixeles
     */
    public int size(){
        return SIZE;
    }

    /**
     * Indica si el símbolo se deja ver en este momento.
     * @return true si la rueda debe dibujarlo
     */
    public boolean isShown(){
        return true;
    }

    /**
     * Le avisa al símbolo que una rueda lo acaba de seleccionar (al
     * girar o al ubicarlo). Un símbolo normal no cambia.
     */
    public void select(){
    }

    /**
     * Consulta la figura con que se dibuja este tipo de símbolo.
     * @return "circle", "square" o "triangle"
     */
    public abstract String shape();

    /**
     * Normaliza un nombre de color: sin espacios alrededor y en minúsculas.
     * @param aColor nombre del color (puede ser null)
     * @return el color normalizado, o "" si era null
     */
    public static String normalize(String aColor){
        return (aColor == null) ? "" : aColor.trim().toLowerCase();
    }
}
