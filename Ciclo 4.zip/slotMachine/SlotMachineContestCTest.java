import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Clase de pruebas COMPARTIDAS del tercer ciclo (creación colectiva del
 * curso). Los casos de este grupo usan las iniciales del autor:
 * Mora Casas (Mc) -> accordingMc...
 *
 * @author  Mora Casas (y demás autores del curso)
 * @version 4.0
 */
public class SlotMachineContestCTest{

    private SlotMachine machine;

    /**
     * Crea el conjunto de pruebas.
     */
    public SlotMachineContestCTest(){
        super();
    }

    /**
     * Antes de cada prueba: cada caso crea sus propias máquinas.
     */
    @BeforeEach
    public void setUp(){
        machine = null;
    }

    /**
     * Limpia después de cada prueba: suelta la máquina usada.
     */
    @AfterEach
    public void tearDown(){
        machine = null;
    }

    /**
     * Para cualquier n, aplicar las acciones de solve debería llevar a
     * una configuración ganadora.
     */
    @Test
    public void accordingMcShouldWinWithTheActionsOfSolve(){
        for(int n = 3; n <= 50; n++){
            machine = new SlotMachine(n);
            SlotMachineContest.solve(machine, n);
            assertEquals(1, machine.distinctSymbols());
        }
    }

    /**
     * solve NO debería usar más de una acción por rueda ni rotar más de
     * media vuelta (las acciones son las necesarias).
     */
    @Test
    public void accordingMcShouldNotReturnUnnecessaryActions(){
        int n = 50;
        int[][] actions = SlotMachineContest.solve(n);
        assertTrue(actions.length <= n);
        for(int[] a : actions){
            assertTrue(Math.abs(a[1]) <= n / 2);
        }
    }
}
