/**
 * ShySymbol es un símbolo tímido: alterna su estado de visible a
 * invisible cada vez que una rueda lo selecciona. Se dibuja como un
 * triángulo para distinguirlo de los demás tipos.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class ShySymbol extends Symbol{

    private boolean shown;

    /**
     * Crea un símbolo tímido del color indicado, inicialmente visible.
     * @param color nombre del color CSS del símbolo
     */
    public ShySymbol(String color){
        super(color);
        shown = true;
    }

    /**
     * Indica si el símbolo tímido se deja ver en este momento.
     * @return true si está visible
     */
    @Override
    public boolean isShown(){
        return shown;
    }

    /**
     * Cada vez que una rueda lo selecciona cambia de visible a
     * invisible, o al revés.
     */
    @Override
    public void select(){
        shown = !shown;
    }

    /**
     * Un símbolo tímido se dibuja como un triángulo.
     * @return "triangle"
     */
    @Override
    public String shape(){
        return "triangle";
    }
}
