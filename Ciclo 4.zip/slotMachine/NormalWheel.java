import java.util.ArrayList;

/**
 * NormalWheel es la rueda de siempre (ciclos 1 a 3): gira al azar, rota
 * paso a paso y se deja fijar, eliminar e intercambiar. Su marco es gris.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class NormalWheel extends Wheel{

    /**
     * Crea una rueda normal.
     * @param catalog   catálogo de símbolos de la máquina
     * @param xPosition posición horizontal inicial de la rueda
     */
    public NormalWheel(ArrayList<Symbol> catalog, int xPosition){
        super(catalog, xPosition);
    }

    /**
     * El marco de una rueda normal es gris claro.
     * @return "gainsboro"
     */
    @Override
    protected String frameColor(){
        return "gainsboro";
    }
}
