import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda de la máquina tragamonedas (clase abstracta).
 * Todas las ruedas comparten el catálogo de símbolos de la máquina y cada
 * una sabe qué símbolo está mostrando y cómo girar.
 * Desde el ciclo 4 hay varios tipos de ruedas (NormalWheel, LeftyWheel,
 * RebelWheel y GamblerWheel). Cada tipo cambia lo que necesite, por
 * ejemplo cómo gira (turn) o el color del marco (frameColor).
 * Se dibuja con un marco (Rectangle) y el símbolo, que puede ser un
 * círculo, un cuadrado o un triángulo según el tipo de símbolo.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public abstract class Wheel{

    private static final int SIZE = Symbol.SIZE;
    private static final int MARGIN = 10;
    private static final int LOCK_MARGIN = 6;
    private static final int Y_POSITION = 60;
    private static final int STEP_DELAY = 120;

    private ArrayList<Symbol> catalog;
    private Symbol current;
    private Rectangle lockFrame;
    private Rectangle frame;
    private Circle circle;
    private Rectangle square;
    private Triangle triangle;
    private Random random;
    private int currentIndex;
    private int xPosition;
    private boolean visible;
    private boolean locked;
    private boolean highlighted;

    /**
     * Crea una rueda que toma sus símbolos del catálogo indicado, en la
     * posición horizontal dada. La rueda queda mostrando el primer
     * símbolo del catálogo, o vacía si el catálogo aún no tiene ninguno.
     * @param catalog   catálogo de símbolos de la máquina a la que pertenece
     * @param xPosition posición horizontal inicial de la rueda
     */
    public Wheel(ArrayList<Symbol> catalog, int xPosition){
        this.catalog = catalog;
        current = null;
        currentIndex = -1;
        visible = false;
        locked = false;
        highlighted = false;
        random = new Random();
        lockFrame = new Rectangle();
        lockFrame.changeSize(SIZE + MARGIN + LOCK_MARGIN, SIZE + MARGIN + LOCK_MARGIN);
        lockFrame.changeColor("red");
        frame = new Rectangle();
        frame.changeSize(SIZE + MARGIN, SIZE + MARGIN);
        frame.changeColor(frameColor());
        circle = new Circle();
        square = new Rectangle();
        triangle = new Triangle();
        reposition(xPosition);
        refresh();
    }

    /**
     * Reubica la rueda en una nueva posición horizontal.
     * @param x nueva posición horizontal
     */
    public void reposition(int x){
        xPosition = x;
        lockFrame.moveTo(x - LOCK_MARGIN / 2, Y_POSITION - MARGIN / 2 - LOCK_MARGIN / 2);
        frame.moveTo(x, Y_POSITION - MARGIN / 2);
        drawSymbol();
    }

    /**
     * Le indica a la rueda cuál es la rueda que tiene a su izquierda.
     * Sólo las ruedas que la necesitan (LeftyWheel) la recuerdan.
     * @param left rueda de la izquierda, o null si es la primera
     */
    public void setLeftNeighbor(Wheel left){
    }

    /**
     * Le indica a la rueda cuál es el símbolo que le falta para que la
     * máquina gane (cuando todas las demás ruedas muestran ese mismo
     * símbolo). Sólo las ruedas que lo necesitan (GamblerWheel) lo usan.
     * @param symbol color del símbolo ganador, o null si no es la última
     *               rueda que falta para ganar
     */
    public void setWinningSymbol(String symbol){
    }

    /**
     * Gira la rueda (al azar, o como lo defina su tipo) y le avisa al
     * símbolo que quedó a la vista que fue seleccionado. Una rueda fija
     * no gira.
     * @return true si la rueda giró; false si está fija o si el
     *         catálogo no tiene símbolos
     */
    public boolean spin(){
        if(locked || catalog.isEmpty()){ return false; }
        turn();
        finishTurn();
        return true;
    }

    /**
     * Rota la rueda el número de pasos indicado (o como lo defina su
     * tipo). Si la rueda está visible, el movimiento se ve paso a paso.
     * Una rueda fija no rota.
     * @param steps cantidad de pasos a rotar (puede ser negativo)
     * @return true si la rueda rotó; false si está fija o si el
     *         catálogo no tiene símbolos
     */
    public boolean spin(int steps){
        if(locked || catalog.isEmpty()){ return false; }
        rotate(steps);
        finishTurn();
        return true;
    }

    /**
     * Deja a la vista el símbolo indicado, siempre que exista en el
     * catálogo, y le avisa que fue seleccionado. Una rueda fija no
     * cambia de símbolo.
     * @param color color del símbolo que debe quedar visible
     * @return true si la rueda no está fija, el símbolo existe en el
     *         catálogo y quedó ubicado
     */
    public boolean place(String color){
        if(locked || !showColor(color)){ return false; }
        finishTurn();
        return true;
    }

    /**
     * Consulta el símbolo que la rueda está mostrando.
     * @return el color del símbolo de la rueda, o null si no tiene
     */
    public String currentSymbol(){
        return (current == null) ? null : current.getColor();
    }

    /**
     * Consulta si la rueda está mostrando el símbolo dado.
     * @param aSymbol símbolo a comparar
     * @return true si la rueda muestra exactamente ese símbolo
     */
    public boolean isShowing(Symbol aSymbol){
        return current != null && current == aSymbol;
    }

    /**
     * Sincroniza la rueda con el catálogo después de que la máquina
     * agregue o elimine símbolos. Si el símbolo que muestra sigue en el
     * catálogo, lo conserva; si fue eliminado, muestra el que quedó en
     * su antigua posición (ajustada al rango). Si el catálogo quedó
     * vacío, la rueda queda sin símbolo.
     */
    public void refresh(){
        if(catalog.isEmpty()){
            show(-1);
            return;
        }
        int index = (current == null) ? -1 : catalog.indexOf(current);
        if(index == -1){ index = currentIndex; }
        if(index < 0){ index = 0; }
        if(index >= catalog.size()){ index = catalog.size() - 1; }
        show(index);
    }

    /**
     * Fija la rueda: mientras está fija no cambia su símbolo.
     * @return true si la rueda se dejó fijar
     */
    public boolean lock(){
        locked = true;
        restack();
        return true;
    }

    /**
     * Suelta la rueda: vuelve a poder girar normalmente.
     */
    public void unlock(){
        locked = false;
        restack();
    }

    /**
     * Consulta si la rueda está fija.
     * @return true si la rueda está actualmente fija
     */
    public boolean isLocked(){
        return locked;
    }

    /**
     * Indica si la rueda se deja eliminar de la máquina.
     * @return true si no está fija
     */
    public boolean isRemovable(){
        return !locked;
    }

    /**
     * Indica si la rueda se deja intercambiar con otra.
     * @return true si no está fija
     */
    public boolean isSwappable(){
        return !locked;
    }

    /**
     * Hace visible la rueda en el lienzo.
     */
    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        restack();
    }

    /**
     * Hace invisible la rueda: la borra del lienzo sin alterar el
     * símbolo que tiene asignado ni su estado de fijado.
     */
    public void makeInvisible(){
        lockFrame.makeInvisible();
        frame.makeInvisible();
        hideSymbol();
        visible = false;
    }

    /**
     * Consulta el estado de visibilidad de la rueda.
     * @return true si la rueda está actualmente visible en el lienzo
     */
    public boolean isVisible(){
        return visible;
    }

    /**
     * Resalta visualmente la rueda (cuando la máquina llega a un estado
     * ganador) y vuelve a dibujar su símbolo, por si éste cambió.
     * @param highlight true para resaltar, false para el estado normal
     */
    public void highlight(boolean highlight){
        highlighted = highlight;
        restack();
    }

    /**
     * Color del marco que identifica a este tipo de rueda.
     * @return nombre del color CSS del marco
     */
    protected abstract String frameColor();

    /**
     * Escoge el nuevo símbolo en un giro. Por defecto, al azar.
     */
    protected void turn(){
        show(random.nextInt(catalog.size()));
    }

    /**
     * Rota la rueda paso a paso dentro del catálogo: avanza con pasos
     * positivos, retrocede con negativos y da la vuelta de forma cíclica.
     * @param steps cantidad de pasos a rotar
     */
    protected void rotate(int steps){
        int index = (current == null) ? 0 : catalog.indexOf(current);
        int direction = (steps >= 0) ? 1 : -1;
        int remaining = Math.abs(steps);
        for(int i = 0; i < remaining; i++){
            index = Math.floorMod(index + direction, catalog.size());
            show(index);
            pauseStep();
        }
    }

    /**
     * Deja a la vista el símbolo del color indicado, sin avisarle.
     * @param color color buscado
     * @return true si el símbolo existe en el catálogo
     */
    protected boolean showColor(String color){
        for(int i = 0; i < catalog.size(); i++){
            if(catalog.get(i).hasColor(color)){
                show(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Termina un giro: le avisa al símbolo que quedó a la vista que fue
     * seleccionado y lo vuelve a dibujar.
     */
    private void finishTurn(){
        if(current != null){ current.select(); }
        drawSymbol();
    }

    /**
     * Vuelve a dibujar las piezas de la rueda en orden: el cuadro rojo
     * (sólo si está fija), encima el marco y de último el símbolo.
     */
    private void restack(){
        if(locked && visible){
            lockFrame.makeVisible();
            lockFrame.changeColor("red");
        } else {
            lockFrame.makeInvisible();
        }
        if(highlighted){
            frame.changeColor("gold");
        } else {
            frame.changeColor(frameColor());
        }
        drawSymbol();
    }

    /**
     * Deja a la vista el símbolo que está en el índice indicado del
     * catálogo. Un índice fuera de rango deja la rueda sin símbolo.
     * @param index posición del símbolo dentro del catálogo
     */
    private void show(int index){
        currentIndex = index;
        boolean inRange = index >= 0 && index < catalog.size();
        current = inRange ? catalog.get(index) : null;
        drawSymbol();
    }

    /**
     * Dibuja el símbolo actual con la figura, el tamaño y el color que
     * indica su tipo. Si no hay símbolo, la rueda no está visible o el
     * símbolo no se deja ver, no se dibuja nada.
     */
    private void drawSymbol(){
        hideSymbol();
        if(!visible || current == null || !current.isShown()){ return; }
        int size = current.size();
        int x = xPosition + MARGIN / 2 + (SIZE - size) / 2;
        int y = Y_POSITION + (SIZE - size) / 2;
        String shape = current.shape();
        if("square".equals(shape)){
            square.changeSize(size, size);
            square.moveTo(x, y);
            square.changeColor(current.getColor());
            square.makeVisible();
        } else if("triangle".equals(shape)){
            triangle.changeSize(size, size);
            triangle.moveTo(x + size / 2, y);
            triangle.changeColor(current.getColor());
            triangle.makeVisible();
        } else {
            circle.changeSize(size);
            circle.moveTo(x, y);
            circle.changeColor(current.getColor());
            circle.makeVisible();
        }
    }

    /**
     * Borra del lienzo las figuras con que se dibuja el símbolo.
     */
    private void hideSymbol(){
        circle.makeInvisible();
        square.makeInvisible();
        triangle.makeInvisible();
    }

    /**
     * Pausa breve entre dos pasos de una rotación, para que el movimiento
     * sea perceptible. Sólo tiene efecto cuando la rueda está visible.
     */
    protected void pauseStep(){
        if(!visible){ return; }
        Canvas.getCanvas().wait(STEP_DELAY);
    }
}
