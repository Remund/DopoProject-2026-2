import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Clase de pruebas COMPARTIDAS del cuarto ciclo (creación colectiva del
 * curso). Los casos de este grupo usan las iniciales del autor:
 * Mora Casas (Mc) -> accordingMc...
 *
 * @author  Mora Casas (y demás autores del curso)
 * @version 4.0
 */
public class SlotMachineCC4Test{

    private SlotMachine machine;

    /**
     * Crea el conjunto de pruebas.
     */
    public SlotMachineCC4Test(){
        super();
    }

    /**
     * Prepara una máquina con una rueda normal, una lefty y una rebel, y
     * los símbolos red, blue y green.
     */
    @BeforeEach
    public void setUp(){
        machine = new SlotMachine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.spin(new String[]{"green", "red", "blue"});
    }

    /**
     * Limpia después de cada prueba.
     */
    @AfterEach
    public void tearDown(){
        machine = null;
    }

    /**
     * Una rueda lefty debería quedar con el símbolo de su vecina izquierda.
     */
    @Test
    public void accordingMcShouldMakeALeftyCopyItsLeftNeighbor(){
        machine.spin(2);
        assertEquals("green", machine.configuration()[1]);
    }

    /**
     * Una rueda rebel NO debería dejarse fijar ni eliminar.
     */
    @Test
    public void accordingMcShouldNotLetARebelBeLockedNorDeleted(){
        machine.lock(3);
        assertFalse(machine.ok());
        machine.delWheel(3);
        assertFalse(machine.ok());
        assertEquals(3, machine.wheelCount());
    }
}
