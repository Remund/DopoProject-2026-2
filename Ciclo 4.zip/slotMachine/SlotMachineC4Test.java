import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad del CUARTO CICLO (requisitos 16 a 19): tipos de
 * ruedas (normal, lefty, rebel y gambler, ésta última propuesta por el
 * autor) y tipos de símbolos (normal, ephemeral y shy). Para cada
 * operación se prueba lo que DEBERÍA hacer y lo que NO DEBERÍA hacer.
 * Todas en modo INVISIBLE.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class SlotMachineC4Test{

    private SlotMachine machine;

    /**
     * Crea el conjunto de pruebas.
     */
    public SlotMachineC4Test(){
        super();
    }

    /**
     * Prepara una máquina nueva, vacía e invisible, antes de cada prueba.
     */
    @BeforeEach
    public void setUp(){
        machine = new SlotMachine();
    }

    /**
     * Limpia después de cada prueba: suelta la máquina usada.
     */
    @AfterEach
    public void tearDown(){
        machine = null;
    }

    /**
     * Agrega al catálogo los símbolos normales red, blue y green.
     */
    private void addThreeSymbols(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
    }

    // ---------- Requisito 16: manejar tipos de ruedas y de símbolos ----------

    /**
     * addWheel(type, pos) debería agregar ruedas de cada tipo.
     */
    @Test
    public void shouldAddWheelsOfEveryType(){
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("gambler", 4);
        assertTrue(machine.ok());
        assertEquals(4, machine.wheelCount());
    }

    /**
     * addWheel(type, pos) NO debería agregar una rueda de un tipo que no
     * existe.
     */
    @Test
    public void shouldNotAddAWheelOfAnUnknownType(){
        machine.addWheel("crazy", 1);
        assertFalse(machine.ok());
        assertEquals(0, machine.wheelCount());
    }

    /**
     * addSymbol(type, pos, color) debería agregar símbolos de cada tipo,
     * respetando el orden.
     */
    @Test
    public void shouldAddSymbolsOfEveryType(){
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("ephemeral", 2, "blue");
        machine.addSymbol("shy", 3, "green");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"}, machine.symbols());
    }

    /**
     * addSymbol(type, pos, color) NO debería agregar un símbolo de un
     * tipo que no existe.
     */
    @Test
    public void shouldNotAddASymbolOfAnUnknownType(){
        machine.addSymbol("ghost", 1, "red");
        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }

    /**
     * addSymbol(type, pos, color) NO debería repetir un color aunque el
     * tipo sea diferente.
     */
    @Test
    public void shouldNotAddARepeatedColorOfAnotherType(){
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("shy", 2, "red");
        assertFalse(machine.ok());
        assertEquals(1, machine.symbols().length);
    }

    // ---------- Requisito 17: lefty ----------

    /**
     * Una rueda lefty debería copiar el estado de la rueda de su
     * izquierda al girar.
     */
    @Test
    public void shouldCopyTheLeftWheelWhenSpinningALefty(){
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        addThreeSymbols();
        machine.spin(new String[]{"blue", "red"});
        machine.spin(2);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[1]);
        machine.spin(1, 1);
        machine.spin(2, 1);
        assertEquals("green", machine.configuration()[1]);
        assertTrue(machine.isJackpot());
    }

    /**
     * Una rueda lefty que es la primera NO debería copiar nada: gira
     * como una rueda normal.
     */
    @Test
    public void shouldNotCopyAnythingWhenTheLeftyIsTheFirstWheel(){
        machine.addWheel("lefty", 1);
        addThreeSymbols();
        machine.placeSymbol(1, "red");
        machine.spin(1, 1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    /**
     * Una rueda lefty debería copiar a su NUEVA vecina después de un
     * intercambio de ruedas.
     */
    @Test
    public void shouldCopyTheNewLeftNeighborAfterASwap(){
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("lefty", 3);
        addThreeSymbols();
        machine.spin(new String[]{"red", "blue", "green"});
        machine.swap(1, 2);
        machine.spin(3);
        assertEquals("red", machine.configuration()[2]);
    }

    /**
     * Una rueda lefty fija NO debería copiar a su vecina.
     */
    @Test
    public void shouldNotCopyWhenTheLeftyIsLocked(){
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        addThreeSymbols();
        machine.spin(new String[]{"blue", "red"});
        machine.lock(2);
        machine.spin(2);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[1]);
    }

    // ---------- Requisito 17: rebel ----------

    /**
     * Una rueda rebel NO debería dejarse fijar.
     */
    @Test
    public void shouldNotLockARebelWheel(){
        machine.addWheel("rebel", 1);
        addThreeSymbols();
        machine.lock(1);
        assertFalse(machine.ok());
        machine.spin(1, 1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    /**
     * Una rueda rebel NO debería dejarse intercambiar.
     */
    @Test
    public void shouldNotSwapARebelWheel(){
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        addThreeSymbols();
        machine.spin(new String[]{"red", "blue"});
        machine.swap(1, 2);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    /**
     * Una rueda rebel NO debería dejarse eliminar.
     */
    @Test
    public void shouldNotDeleteARebelWheel(){
        machine.addWheel("rebel", 1);
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertEquals(1, machine.wheelCount());
    }

    /**
     * Una rueda normal debería seguir dejándose fijar, intercambiar y
     * eliminar (los tipos nuevos no cambian la rueda de siempre).
     */
    @Test
    public void shouldKeepTheNormalWheelBehavior(){
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.lock(1);
        assertTrue(machine.ok());
        machine.unlock(1);
        machine.swap(1, 2);
        assertTrue(machine.ok());
        machine.delWheel(1);
        assertTrue(machine.ok());
        assertEquals(1, machine.wheelCount());
    }

    // ---------- Requisito 19: gambler (propuesto) ----------

    /**
     * Arma una máquina de tres ruedas (normal, normal, gambler) con diez
     * símbolos y la deja en la configuración indicada.
     * @param config configuración inicial de las tres ruedas
     * @return la máquina armada
     */
    private SlotMachine gamblerMachine(String[] config){
        SlotMachine m = new SlotMachine();
        m.addWheel("normal", 1);
        m.addWheel("normal", 2);
        m.addWheel("gambler", 3);
        String[] colors = {"red", "blue", "green", "yellow", "purple",
                           "pink", "brown", "cyan", "navy", "olive"};
        for(int i = 0; i < colors.length; i++){
            m.addSymbol(i + 1, colors[i]);
        }
        m.spin(config);
        return m;
    }

    /**
     * Una rueda gambler que es la última que falta para ganar debería
     * ganar la mayoría de las veces (con tres intentos de 25 %, 50 % y
     * 75 % la probabilidad de ganar es de más del 90 %).
     */
    @Test
    public void shouldWinMostOfTheTimesWhenTheGamblerIsTheLastWheel(){
        int wins = 0;
        for(int i = 0; i < 200; i++){
            SlotMachine m = gamblerMachine(new String[]{"red", "red", "blue"});
            m.spin(3);
            assertTrue(m.ok());
            if(m.isJackpot()){ wins++; }
        }
        assertTrue(wins >= 150);
    }

    /**
     * Una rueda gambler que NO es la última que falta para ganar NO
     * debería hacer trampa: gira al azar como una rueda normal.
     */
    @Test
    public void shouldNotCheatWhenTheGamblerIsNotTheLastWheel(){
        int reds = 0;
        for(int i = 0; i < 200; i++){
            SlotMachine m = gamblerMachine(new String[]{"red", "blue", "green"});
            m.spin(3);
            if("red".equals(m.configuration()[2])){ reds++; }
        }
        assertTrue(reds < 60);
    }

    /**
     * Una rueda gambler también debería apostar cuando giran todas las
     * ruedas de la máquina con spin().
     */
    @Test
    public void shouldGambleWhenSpinningTheWholeMachine(){
        machine.addWheel("normal", 1);
        machine.addWheel("gambler", 2);
        addThreeSymbols();
        int wins = 0;
        for(int i = 0; i < 100; i++){
            machine.unlock(1);
            machine.spin(new String[]{"red", "blue"});
            machine.lock(1);
            machine.spin();
            assertTrue(machine.ok());
            assertEquals("red", machine.configuration()[0]);
            if(machine.isJackpot()){ wins++; }
        }
        assertTrue(wins >= 75);
    }

    /**
     * Una rueda gambler fija NO debería apostar ni girar.
     */
    @Test
    public void shouldNotGambleWhenTheGamblerIsLocked(){
        SlotMachine m = gamblerMachine(new String[]{"red", "red", "blue"});
        m.lock(3);
        m.spin(3);
        assertFalse(m.ok());
        assertEquals("blue", m.configuration()[2]);
    }

    // ---------- Requisito 18: ephemeral y shy ----------

    /**
     * Un símbolo ephemeral debería encogerse cada vez que lo seleccionan.
     */
    @Test
    public void shouldShrinkAnEphemeralSymbolOnEverySelection(){
        Symbol symbol = new EphemeralSymbol("red");
        assertEquals(Symbol.SIZE, symbol.size());
        symbol.select();
        assertEquals(Symbol.SIZE - EphemeralSymbol.STEP, symbol.size());
    }

    /**
     * Un símbolo ephemeral NO debería encogerse más allá de un punto.
     */
    @Test
    public void shouldNotShrinkAnEphemeralSymbolBelowADot(){
        Symbol symbol = new EphemeralSymbol("red");
        for(int i = 0; i < 20; i++) symbol.select();
        assertEquals(EphemeralSymbol.MIN_SIZE, symbol.size());
        assertTrue(symbol.isShown());
    }

    /**
     * Un símbolo shy debería alternar entre visible e invisible cada vez
     * que lo seleccionan.
     */
    @Test
    public void shouldToggleAShySymbolOnEverySelection(){
        Symbol symbol = new ShySymbol("red");
        assertTrue(symbol.isShown());
        symbol.select();
        assertFalse(symbol.isShown());
        symbol.select();
        assertTrue(symbol.isShown());
    }

    /**
     * Un símbolo normal NO debería cambiar al ser seleccionado.
     */
    @Test
    public void shouldNotChangeANormalSymbolWhenSelected(){
        Symbol symbol = new NormalSymbol("red");
        symbol.select();
        assertTrue(symbol.isShown());
        assertEquals(Symbol.SIZE, symbol.size());
    }

    /**
     * Cada tipo de símbolo debería dibujarse con una figura diferente
     * (requisito de usabilidad).
     */
    @Test
    public void shouldUseADifferentShapeForEverySymbolType(){
        assertEquals("circle", new NormalSymbol("red").shape());
        assertEquals("square", new EphemeralSymbol("red").shape());
        assertEquals("triangle", new ShySymbol("red").shape());
    }

    /**
     * Un símbolo shy escondido NO debería salir de la configuración: la
     * rueda sigue mostrando ese símbolo aunque no se vea.
     */
    @Test
    public void shouldNotLoseAHiddenShySymbolFromTheConfiguration(){
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol("normal", 2, "blue");
        machine.spin(new String[]{"red", "red"});
        assertArrayEquals(new String[]{"red", "red"}, machine.configuration());
        assertTrue(machine.isJackpot());
    }

    /**
     * Las ruedas debería seguir funcionando con símbolos ephemeral: rotar
     * pasos sobre ellos los recorre en el orden del catálogo.
     */
    @Test
    public void shouldRotateOverEphemeralSymbols(){
        machine.addWheel("normal", 1);
        machine.addSymbol("ephemeral", 1, "red");
        machine.addSymbol("ephemeral", 2, "blue");
        machine.spin(1, 1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }
    // ---------- Requisito de usabilidad: tipos distinguibles visualmente ----------

    /**
     * Con el simulador visible, la máquina debería dibujar cada tipo de
     * rueda y de símbolo sin dejar de funcionar.
     */
    @Test
    public void shouldDrawEveryTypeWhenVisible(){
        machine.makeVisible();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("gambler", 4);
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("ephemeral", 2, "blue");
        machine.addSymbol("shy", 3, "green");
        machine.spin(new String[]{"red", "blue", "green", "blue"});
        machine.spin(4, 1);
        machine.lock(1);
        assertTrue(machine.ok());
        assertTrue(machine.isVisible());
        assertArrayEquals(new String[]{"red", "blue", "green", "green"}, machine.configuration());
        machine.makeInvisible();
        assertFalse(machine.isVisible());
    }

    /**
     * Con el simulador visible, un símbolo shy escondido NO debería
     * impedir que la máquina llegue al jackpot.
     */
    @Test
    public void shouldNotLoseTheJackpotWhenAShySymbolHidesWhileVisible(){
        machine.makeVisible();
        machine.addWheel("normal", 1);
        machine.addSymbol("shy", 1, "green");
        machine.placeSymbol(1, "green");
        assertTrue(machine.ok());
        assertTrue(machine.isJackpot());
        machine.makeInvisible();
    }
}
