import java.util.ArrayList;

/**
 * RebelWheel es una rueda rebelde: no se deja fijar, ni intercambiar,
 * ni eliminar. Gira como una rueda normal. Su marco es naranja.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class RebelWheel extends Wheel{

    /**
     * Crea una rueda rebelde.
     * @param catalog   catálogo de símbolos de la máquina
     * @param xPosition posición horizontal inicial de la rueda
     */
    public RebelWheel(ArrayList<Symbol> catalog, int xPosition){
        super(catalog, xPosition);
    }

    /**
     * Una rueda rebelde no se deja fijar.
     * @return false siempre
     */
    @Override
    public boolean lock(){
        return false;
    }

    /**
     * Una rueda rebelde no se deja eliminar.
     * @return false siempre
     */
    @Override
    public boolean isRemovable(){
        return false;
    }

    /**
     * Una rueda rebelde no se deja intercambiar.
     * @return false siempre
     */
    @Override
    public boolean isSwappable(){
        return false;
    }

    /**
     * El marco de una rueda rebelde es naranja.
     * @return "orange"
     */
    @Override
    protected String frameColor(){
        return "orange";
    }
}
