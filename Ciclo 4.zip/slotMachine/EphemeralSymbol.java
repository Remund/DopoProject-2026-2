/**
 * EphemeralSymbol es un símbolo efímero: en cada giro en que una rueda
 * lo selecciona va decrementando su tamaño, hasta quedar como un punto.
 * Se dibuja como un cuadrado para distinguirlo de los demás tipos.
 *
 * @author  Mora Casas
 * @version 4.0
 */
public class EphemeralSymbol extends Symbol{

    /** Tamaño mínimo: el símbolo queda como un punto. */
    public static final int MIN_SIZE = 4;
    /** Cuánto se encoge en cada giro. */
    public static final int STEP = 10;

    private int currentSize;

    /**
     * Crea un símbolo efímero del color indicado, de tamaño completo.
     * @param color nombre del color CSS del símbolo
     */
    public EphemeralSymbol(String color){
        super(color);
        currentSize = SIZE;
    }

    /**
     * Consulta el tamaño actual del símbolo efímero.
     * @return tamaño en pixeles (nunca menor que MIN_SIZE)
     */
    @Override
    public int size(){
        return currentSize;
    }

    /**
     * Cada vez que una rueda lo selecciona se encoge, sin bajar del
     * tamaño mínimo (un punto).
     */
    @Override
    public void select(){
        currentSize = currentSize - STEP;
        if(currentSize < MIN_SIZE){
            currentSize = MIN_SIZE;
        }
    }

    /**
     * Un símbolo efímero se dibuja como un cuadrado.
     * @return "square"
     */
    @Override
    public String shape(){
        return "square";
    }
}
